//
// Created by gordeser on 11.05.2023.
//

#include "MatrixCalculator.h"

/**
 * Main functions that starts the application
 */
int main() {
    MatrixCalculator app;
    app.runApplication();
    return 0;
}