//
// Created by gordeser on 14.05.2023.
//

#ifndef PA2_PARSER_H
#define PA2_PARSER_H

#include <vector>
#include <string>

class Parser {
public:
    std::vector<std::string> parseInput();
};

#endif //PA2_PARSER_H
