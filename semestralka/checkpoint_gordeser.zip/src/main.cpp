//
// Created by gordeser on 11.05.2023.
//

#include "MatrixCalculator.h"

int main() {
    MatrixCalculator app;
    app.runApplication();
    return 0;
}