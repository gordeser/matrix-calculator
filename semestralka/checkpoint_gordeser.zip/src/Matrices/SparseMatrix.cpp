//
// Created by gordeser on 14.05.2023.
//

#include "SparseMatrix.h"

SparseMatrix::SparseMatrix(std::size_t numRows, std::size_t numCols) : Matrix(numRows, numCols) {}
