//
// Created by gordeser on 15.05.2023.
//

#include "JoiningDownOperation.h"
